/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministockapp;

/**
 *
 * @author hp255-g3
 */
public class Item {
    private static int currentItemId = 100;
    private String itemId;
    private String name;
    private double costPrice;
    private  int amount = 0;
    private User userContext = null;
    public Item(String name, double costPrice) {
        this.name = name;
        this.costPrice = ((int) (costPrice * 100))/100.00;
        this.itemId = "I" + currentItemId;
        currentItemId++;
        
    }
    String getName() {
        return this.name;
    }
    double getCostPrice() {
        return this.costPrice;
    }
    void setCostPrice(double costPrice) {
        this.costPrice = ((int)(costPrice * 100)) / 100.00;
    }
    int getAmount() {
        return this.amount;
    }
    void addItem(int amount) {
        this.amount = this.amount + amount;
    }
    void subtractItem(int amount) {
        this.amount = this.amount - amount;
    }
    void setUserContext(User user) {
        if (Repo.getAllUserName().contains(user.getUserName())) {
            this.userContext = user;
        } else {
            System.out.println("User not found");
        }
    }
    User getUserContext() {
        return this.userContext;
    }
    String getId() {
        return this.itemId;
    }
    
}
