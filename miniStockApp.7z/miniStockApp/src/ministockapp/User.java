/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministockapp;

/**
 *
 * @author hp255-g3
 */
public class User {
    private String userName;
    private String password;
   
   public User(String userName, String password) {
       this.userName = userName;
       this.password = password;
   } 
   String getUserName() {
        return this.userName;
    }
   String getPassword() {
        return this.password;
    }
   void setUserName(String userName) {
       this.userName = userName;
   }
   void setPassword(String password) {
       this.password = password;
   }
    
}
