/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministockapp;

import java.util.Comparator;

/**
 *
 * @author hp255-g3
 */
public class Transaction {
    private static int currentTranactionId;
    private final String transactionId;
    private final Item item;
    private final double sellingPrice;
    private final long transactionTimeStamp;
    private int amount=1;
    private final double netIncome;
    
    public Transaction(Item item, double sellingPrice, int amount) {
        this.item = item;
        this.sellingPrice = ((int) (sellingPrice * 100)) / 100.00;
        this.amount = amount;
        this.netIncome = (sellingPrice * amount) - (item.getCostPrice() * amount);
        this.transactionId = "tran/" + Transaction.currentTranactionId;
        Transaction.currentTranactionId++;
        this.transactionTimeStamp =  new java.util.Date().getTime();
    }
    String getTranactioinId() {
        return this.transactionId;
    }
    Item getItem() {
        return this.item;
    }
    double getSellingPrice() {
        return this.sellingPrice;
    }
    long getTransactionTimeStamp() {
        return this.transactionTimeStamp;
    }
    java.util.Date detTransactionDate() {
        return new java.util.Date(this.transactionTimeStamp);
    }
    int getAmount() {
        return this.amount;
    }
    double getnetIncome() {
        return this.netIncome;
    }

    
}
