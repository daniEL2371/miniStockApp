/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministockapp;

import java.util.ArrayList;

/**
 *
 * @author hp255-g3
 */
public class stockManger {
    private static String messageStatus = "";
    static boolean defineItem(Item i) {
        if (AccountManger.getLoginUser() == null) {
            messageStatus = "You are not authenticated for this request!";
            return false;
        }
        i.setUserContext(AccountManger.getLoginUser());
        
        if (Repo.storeItem(i)) {
            messageStatus = "You have " + "sucessfully created new item called " + i.getName();
            return true;
        } else {
            messageStatus = "Ooops something went wrong, cant create item!";
            return false;
        }
    }
    static boolean addItem(Item item, int amount) {
       if (AccountManger.getLoginUser() == null) {
           messageStatus = "You are not authenticated for this request!";
           return false;
       } 
       if (!item.getUserContext().getUserName().equals(AccountManger.getLoginUser().getUserName())) {
          messageStatus = "You are not authenticated for this request!";
          return false;
       }
        if (Repo.addItem(item, amount)) {
             messageStatus = amount + " amount of " + item.getName() + " sucessfully added";
             return true;
        } else {
             messageStatus = "Ooops something went wrong, cant added item!";
             return false;
        }
    }
    static ArrayList<String[]> getStoreStatus() {
        ArrayList<String[]> result = new ArrayList<String[]>();
        
        for (Item i: Repo.getAllItems(AccountManger.getLoginUser())) {
         String[] temp= {"s","w"};
         result.add(temp);
        }
        return result;
    }
    static boolean recordSoldItem(String itemId, int amount, double sellingPrice) {
        Item item = Repo.getItemById(itemId);
        if (item != null) {
           if ((item.getAmount() - amount) < 0) {
               messageStatus = "You have insufficent amount \n Opreation could not procced";
               return false;
           }
           if (!item.getUserContext().getUserName().equals(AccountManger.getLoginUser().getUserName())){
                messageStatus = "You are not authenticated for this request!";
                return false;
           }
           if (Repo.substractItem(item, amount)) {
               if (TransactionController.saveTransaction(item, sellingPrice, amount)) {
                   messageStatus = "Sold item saved";
                   return true;
               } else {
                   messageStatus = "Oops transaction was not successfully terminated";
                   return false;
               }
           } else {
               messageStatus = "Oops something went wrong";
               return false;
           }
        }
        messageStatus = "Item not found";
        return false;
    }

    static String getMessageStatus() {
        return stockManger.messageStatus;
    }
}
