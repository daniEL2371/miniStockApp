/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministockapp;

import java.util.ArrayList;

/**
 *
 * @author hp255-g3
 */
public class Repo {
    private static ArrayList<User> Users= new ArrayList<User>();
    private static ArrayList<Item> items= new ArrayList<Item>();
    private static ArrayList<Transaction> transactions= new ArrayList<Transaction>();
    
    public static void intialize() {
        
    }
    public static boolean addUser(User user) {
        return Users.add(user);
    }
    
    public static ArrayList<String> getAllUserName() {
        ArrayList<String> userNames = new ArrayList<String>();
        for (User user: Users) {
            userNames.add(user.getUserName());
        }
        return userNames;
    }
    public static User findUser(String userName, String password) {
        for (User user: Users) {
            if ((user.getUserName().equals(userName)) && (user.getPassword().equals(password))) {
                return user;
            }
        }
        return null;
    }
    public static ArrayList<Item> getAllItems(User userContext) {
       ArrayList<Item> foundItems = new ArrayList<Item>();
       for (Item item: items) {
           if (item.getUserContext().getUserName() == null ? userContext.getUserName() == null : item.getUserContext().getUserName().equals(userContext.getUserName())) {
               foundItems.add(item);
           }
       }
       return foundItems;
        
    }
    public static boolean storeItem(Item i) {
        return items.add(i);
    }
    public static boolean addItem(Item item, int amount) {
        for (Item i : items) {
            if (i.getId().equals(item.getId())) {
                i.addItem(amount);
                return true;
             }
         }
        return false;
    }
    public static Item getItemById(String id) {
         for (Item i : items) {
             if (i.getId().equals(id)) {
                 return i;
             }
         }
         return null;
    }
    public static boolean substractItem(Item item, int amount) {
        for (Item i: items) {
            if (i.getId().equals(item.getId())) {
                i.subtractItem(amount);
                return true;
            }
        }
        return false;
    }

    static ArrayList<Transaction> getAllTransactions() {
      return transactions;
    }

    static boolean saveTransactioin(Transaction transaction) {
       return transactions.add(transaction);
    }

    static boolean updateUser(String newUserName, String oldUserName, String password) {
       if (Repo.findUser(oldUserName, password) == null) {
            return false;
       }
       Repo.findUser(oldUserName, password).setUserName(newUserName);
       return true;
    }

    static boolean updateUser(String newUserName, String oldUserName, String newPassword, String password) {
        if (Repo.findUser(oldUserName, password) == null) {
            return false;
        }
        Repo.findUser(oldUserName, password).setUserName(newUserName);
        Repo.findUser(oldUserName, password).setPassword(newPassword);
        return true;
    }
        
}
