/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministockapp;

import java.util.ArrayList;

/**
 *
 * @author hp255-g3
 */
public class AccountManger {
    private static boolean logInStatus = false;
    private static User logInUser = null;
    private static String messageStatus = "";
    public static boolean addAccount(String userName, String password) {
        if (AccountManger.validateUserName(userName)) {
            if (AccountManger.validatePassword(password)) {
                if (Repo.addUser(new User(userName, password))) {
                    AccountManger.messageStatus = "Account successfully added";
                } else {
                     AccountManger.messageStatus = "Ooops something went wrong!";
                }
               
                return true;
            } else {
                AccountManger.messageStatus = "Password must be at least 4 characters long and contain a letter,\n" +
                                              "a number and a symbol and must not contain whitespaces";
                return false;
            }
        } else {
            AccountManger.messageStatus = "Username already exist";
            return false;
        }
    } 
    public static boolean logIn(String userName, String password) {
        if (AccountManger.AuthenticateUser(userName, password)) {
            logInUser = new User(userName, password);
            logInStatus = true;
            return true;
        } else {
           messageStatus = "Inccorect Username or password" ;
           return false;
        }
    }
    private static boolean validateUserName(String userName) {
        ArrayList<String> userNames= Repo.getAllUserName();
        return !(userNames.contains(userName));
        
    }
    private static boolean validatePassword(String password) {
       return PasswordManger.validatePassword(password);
        
    }
    private static boolean AuthenticateUser(String userName, String password) {
        User foundUser = null;
        foundUser = Repo.findUser(userName, password);
        
        return foundUser != null;
    }
    public static User getLoginUser() {
         if (AccountManger.logInStatus) {
            return AccountManger.logInUser; 
         } else {
             messageStatus = "User is not Logged in";
             return null;
         }
    }
    public static String getMessageStatus() {
        return messageStatus;
    }

    public static void logout() {
        AccountManger.logInStatus = false;
        AccountManger.logInUser = null;
    }

    static boolean updateUser(String newUserName, String newPassword, String oldPassword) {
        if (!AccountManger.validateUserName(newUserName) && !newUserName.equals(logInUser.getUserName())) {
            messageStatus = "The username is already taken";
            return false;
        }
        if (!oldPassword.equals(logInUser.getPassword())){
            messageStatus = "Incorrect password!";
            return false;
        }
        if (!AccountManger.validatePassword(newPassword)) {
            AccountManger.messageStatus = "Password must be at least 4 characters long and contain a letter,\n" +
                                              "a number and a symbol and must not contain whitespaces";
            return false;
        }
        if(Repo.updateUser(newUserName, logInUser.getUserName(), newPassword, logInUser.getPassword())) {
            logInUser.setUserName(newUserName);
            logInUser.setPassword(newPassword);
            messageStatus = "User updated successfully";
            return true;
        } else {
             messageStatus = "Ooops some thing went wrong!";
             return false;
        }
        
        
    }

    static boolean updateUser(String newUserName) {
        
        if (!AccountManger.validateUserName(newUserName) && !newUserName.equals(logInUser.getUserName())) {
            messageStatus = "The username is already taken";
            return false;
        }
        if (Repo.updateUser(newUserName, logInUser.getUserName(), logInUser.getPassword())) {
            messageStatus = "User name updated successfully";
            logInUser.setUserName(newUserName);
            return true;
            
        } else {
            messageStatus = "Ooops some thing went wrong!";
            return false;
        }   
            
        
    }
   
    
}
