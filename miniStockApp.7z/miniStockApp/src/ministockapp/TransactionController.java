/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministockapp;

import java.util.ArrayList;
import java.util.Comparator;

/**
 *
 * @author hp255-g3
 */
public class TransactionController {
   
    static ArrayList<Transaction> getAlltransaction() {
        ArrayList<Transaction> transactions = Repo.getAllTransactions();
        return transactions;
        
    }

    static boolean saveTransaction(Item item, double sellingPrice, int amount) {
       return Repo.saveTransactioin(new Transaction(item, ((int)(sellingPrice * 100))/100.00, amount));
       
    }
    
    
}
