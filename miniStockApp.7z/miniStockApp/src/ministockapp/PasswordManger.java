/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ministockapp;

/**
 *
 * @author hp255-g3
 */
public class PasswordManger {
    public static boolean validatePassword(String password) {
        boolean letter, number, symbol;
        number = symbol = letter = false;
        char[] passChar = password.toCharArray();
        if (passChar.length < 4) {
            return false;
        }
        for (char c : passChar) {
            if (Character.isWhitespace(c)) {
                return false;
            }
            else if (Character.isLetter(c)) {
                letter = true;
            } else if (Character.isDigit(c)) {
                number = true;
            } else {
                symbol = true;
            }
        }
        return letter && number && number && symbol;
    }
}
