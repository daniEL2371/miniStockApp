.Mini stock app is a demo app developed using MVC architecture.
.The entire purpose of this app is just to demonstrate how to apply MVC architecture.
.Model classes= {Item, Transaction, User}
.Controller classes = {stockManger, AccountManger, PasswordManger, Transaction Controller}
.A Repo class is a class that acts like persistent storage.
.View classes are JFrame classes.